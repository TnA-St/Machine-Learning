# Đồ án Học máy: Phân tích và dự đoán kết quả học tập sinh viên

## 1. Mục tiêu
Xây dựng ứng dụng minh hoạ quy trình học máy: chuẩn bị dữ liệu, tiền xử lý, huấn luyện, đánh giá và sử dụng mô hình để dự đoán điểm/kết quả học tập.

## 2. Các thuật toán liên hệ với tài liệu môn học
- **Linear Regression**: dự đoán điểm cuối kỳ (bài toán hồi quy).
- **Logistic Regression, KNN, Naive Bayes, Decision Tree, Random Forest, SVM**: phân loại Đạt/Chưa đạt.
- **K-Means**: phân nhóm sinh viên theo đặc điểm học tập (học không giám sát).
- **Đánh giá mô hình**: MAE, RMSE, R²; Accuracy, Precision, Recall, F1 và ma trận nhầm lẫn.

## 3. Cấu trúc thư mục
```
ML_Project/
├── app.py
├── generate_data.py
├── train_models.py
├── requirements.txt
├── README.md
├── data/student_performance.csv
├── models/                 # tạo sau khi chạy train_models.py
└── reports/                # các chỉ số đánh giá và thống kê cụm
```

## 4. Cài đặt và chạy
Khuyến nghị Python 3.10–3.12.

```bash
python -m venv .venv
```
Kích hoạt môi trường:
- Windows: `.venv\Scripts\activate`
- macOS/Linux: `source .venv/bin/activate`

Cài thư viện và huấn luyện:
```bash
pip install -r requirements.txt
python train_models.py
streamlit run app.py
```
Mở địa chỉ local mà Streamlit hiển thị trên terminal.

Nếu muốn tạo lại dữ liệu minh hoạ:
```bash
python generate_data.py
python train_models.py
```

## 5. Dữ liệu và giới hạn
`data/student_performance.csv` là **dữ liệu mô phỏng được tạo bằng mã nguồn**, không phải dữ liệu sinh viên thật. Các chỉ số đánh giá chỉ phục vụ minh hoạ quy trình; không nên trình bày chúng như kết quả nghiên cứu thực tế. Nếu giảng viên yêu cầu dữ liệu thực, cần thay CSV bằng bộ dữ liệu được phép sử dụng và chạy huấn luyện lại.

## 6. Gợi ý bố cục báo cáo
1. Lý do chọn đề tài và bài toán.
2. Mục tiêu, phạm vi và mô tả dữ liệu.
3. Tiền xử lý: xử lý giá trị thiếu, chuẩn hoá biến số, mã hoá biến phân loại.
4. Cơ sở lý thuyết các thuật toán.
5. Thiết kế thực nghiệm: chia train/test, cùng tập kiểm tra cho các mô hình phân loại.
6. Kết quả và so sánh chỉ số.
7. Giao diện ứng dụng và ví dụ dự đoán.
8. Hạn chế, đạo đức dữ liệu và hướng phát triển.

## 7. Lưu ý học thuật
Dữ liệu tổng hợp giúp demo kỹ thuật, nhưng không chứng minh mô hình có thể dự đoán chính xác kết quả học tập ngoài đời. Cần giải thích giới hạn này trong phần kết luận.
