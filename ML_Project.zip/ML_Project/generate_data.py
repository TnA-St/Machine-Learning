import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
n = 600
study_hours = rng.uniform(0, 8, n).round(1)
attendance = rng.uniform(45, 100, n).round(1)
assignment_avg = rng.uniform(35, 100, n).round(1)
previous_score = rng.uniform(30, 100, n).round(1)
sleep_hours = rng.normal(7, 1.2, n).clip(3.5, 10).round(1)
internet_access = rng.choice(['Yes', 'No'], n, p=[0.88, 0.12])
extracurricular = rng.choice(['Yes', 'No'], n, p=[0.45, 0.55])
noise = rng.normal(0, 6, n)
score = (18 + 2.7*study_hours + 0.20*attendance + 0.19*assignment_avg + 0.18*previous_score + 1.2*(sleep_hours-6.5) + (internet_access=='Yes')*2 + (extracurricular=='Yes')*1 + noise)
score = np.clip(score, 0, 100).round(1)
df = pd.DataFrame({'study_hours_per_day': study_hours, 'attendance_percent': attendance, 'assignment_average': assignment_avg, 'previous_exam_score': previous_score, 'sleep_hours': sleep_hours, 'internet_access': internet_access, 'extracurricular': extracurricular, 'final_score': score})
df['pass_status'] = np.where(df['final_score'] >= 50, 'Pass', 'Fail')
out = Path(__file__).parent / 'data' / 'student_performance.csv'
df.to_csv(out, index=False)
print(f'Created {out} with {len(df)} rows')
