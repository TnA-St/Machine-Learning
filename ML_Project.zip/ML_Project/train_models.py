from pathlib import Path
import json
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

ROOT = Path(__file__).parent
DATA = ROOT / 'data' / 'student_performance.csv'
MODEL_DIR = ROOT / 'models'; MODEL_DIR.mkdir(exist_ok=True)
REPORT_DIR = ROOT / 'reports'; REPORT_DIR.mkdir(exist_ok=True)
df = pd.read_csv(DATA)
features = ['study_hours_per_day','attendance_percent','assignment_average','previous_exam_score','sleep_hours','internet_access','extracurricular']
target_reg = 'final_score'; target_cls = 'pass_status'
num_features = ['study_hours_per_day','attendance_percent','assignment_average','previous_exam_score','sleep_hours']
cat_features = ['internet_access','extracurricular']
preprocess = ColumnTransformer([('num', Pipeline([('imputer', SimpleImputer(strategy='median')), ('scaler', StandardScaler())]), num_features), ('cat', Pipeline([('imputer', SimpleImputer(strategy='most_frequent')), ('onehot', OneHotEncoder(handle_unknown='ignore'))]), cat_features)])
X = df[features]
X_train, X_test, y_train, y_test = train_test_split(X, df[target_reg], test_size=0.2, random_state=42)
reg = Pipeline([('preprocess', preprocess), ('model', LinearRegression())])
reg.fit(X_train, y_train); pred = reg.predict(X_test)
reg_metrics = {'MAE': round(float(mean_absolute_error(y_test,pred)),3), 'RMSE': round(float(mean_squared_error(y_test,pred)**0.5),3), 'R2': round(float(r2_score(y_test,pred)),3)}
joblib.dump(reg, MODEL_DIR/'linear_regression.joblib')

X_train_c, X_test_c, y_train_c, y_test_c = train_test_split(X, df[target_cls], test_size=0.2, random_state=42, stratify=df[target_cls])
classifiers = {
 'Logistic Regression': LogisticRegression(max_iter=2000),
 'KNN': KNeighborsClassifier(n_neighbors=7),
 'Naive Bayes': GaussianNB(),
 'Decision Tree': DecisionTreeClassifier(max_depth=5, random_state=42),
 'Random Forest': RandomForestClassifier(n_estimators=150, max_depth=8, random_state=42),
 'SVM': SVC(kernel='rbf', C=1.0)
}
metrics=[]
for name, estimator in classifiers.items():
    pipe = Pipeline([('preprocess', preprocess), ('model', estimator)])
    pipe.fit(X_train_c, y_train_c); p = pipe.predict(X_test_c)
    metrics.append({'Model':name, 'Accuracy':round(float(accuracy_score(y_test_c,p)),3), 'Precision':round(float(precision_score(y_test_c,p,pos_label='Pass',zero_division=0)),3), 'Recall':round(float(recall_score(y_test_c,p,pos_label='Pass',zero_division=0)),3), 'F1':round(float(f1_score(y_test_c,p,pos_label='Pass',zero_division=0)),3)})
    safe = name.lower().replace(' ','_')
    joblib.dump(pipe, MODEL_DIR/f'{safe}.joblib')
    if name == 'Random Forest':
        labels = ['Fail','Pass']; cm = confusion_matrix(y_test_c,p,labels=labels).tolist()
        (REPORT_DIR/'confusion_matrix.json').write_text(json.dumps({'labels':labels,'matrix':cm},ensure_ascii=False,indent=2),encoding='utf-8')
metrics_df = pd.DataFrame(metrics).sort_values('F1',ascending=False)
metrics_df.to_csv(REPORT_DIR/'classification_metrics.csv',index=False)
(REPORT_DIR/'regression_metrics.json').write_text(json.dumps(reg_metrics,indent=2),encoding='utf-8')

# K-Means clustering on numeric student attributes; this is exploratory and does not use pass label.
cluster_cols = num_features
cluster_pipe = Pipeline([('imputer',SimpleImputer(strategy='median')),('scaler',StandardScaler())])
Z = cluster_pipe.fit_transform(df[cluster_cols])
kmeans = KMeans(n_clusters=3,random_state=42,n_init=10).fit(Z)
joblib.dump({'preprocess':cluster_pipe,'model':kmeans,'columns':cluster_cols},MODEL_DIR/'kmeans_clusters.joblib')
cluster_summary = df.copy(); cluster_summary['cluster'] = kmeans.labels_
cluster_summary.groupby('cluster')[cluster_cols+['final_score']].mean().round(2).to_csv(REPORT_DIR/'cluster_summary.csv')
print('Regression metrics:', reg_metrics)
print(metrics_df.to_string(index=False))
print('Saved models and reports in', ROOT)
