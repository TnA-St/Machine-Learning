from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px

ROOT = Path(__file__).parent
DATA = ROOT/'data'/'student_performance.csv'
MODELS = ROOT/'models'
REPORTS = ROOT/'reports'
st.set_page_config(page_title='Student Performance ML', page_icon='🎓', layout='wide')
st.title('🎓 Student Performance — Machine Learning')
st.caption('Đồ án minh hoạ các thuật toán Học máy: Linear Regression, Logistic Regression, KNN, Naive Bayes, Decision Tree, Random Forest, SVM và K-Means.')
if not (MODELS/'linear_regression.joblib').exists():
    st.warning('Chưa có mô hình đã huấn luyện. Hãy chạy: python train_models.py')
    st.stop()
df = pd.read_csv(DATA)
reg = joblib.load(MODELS/'linear_regression.joblib')
models = {
 'Logistic Regression':'logistic_regression.joblib', 'KNN':'knn.joblib', 'Naive Bayes':'naive_bayes.joblib',
 'Decision Tree':'decision_tree.joblib', 'Random Forest':'random_forest.joblib', 'SVM':'svm.joblib'
}
tab1, tab2, tab3, tab4 = st.tabs(['Dự đoán cá nhân','So sánh mô hình','Khám phá dữ liệu','Phân cụm K-Means'])
with tab1:
    st.subheader('Nhập thông tin học tập')
    c1,c2,c3 = st.columns(3)
    with c1:
        hours = st.slider('Giờ tự học mỗi ngày',0.0,12.0,3.0,0.5)
        attendance = st.slider('Tỷ lệ chuyên cần (%)',0.0,100.0,85.0,1.0)
        assignment = st.slider('Điểm bài tập trung bình',0.0,100.0,75.0,1.0)
    with c2:
        previous = st.slider('Điểm bài thi trước',0.0,100.0,70.0,1.0)
        sleep = st.slider('Số giờ ngủ mỗi ngày',3.0,12.0,7.0,0.5)
        internet = st.selectbox('Có Internet để học?', ['Yes','No'])
    with c3:
        extracurricular = st.selectbox('Tham gia hoạt động ngoại khóa?', ['Yes','No'])
        selected = st.selectbox('Thuật toán phân loại', list(models.keys()), index=4)
        st.write('')
        run = st.button('Dự đoán kết quả', type='primary', use_container_width=True)
    sample = pd.DataFrame([{'study_hours_per_day':hours,'attendance_percent':attendance,'assignment_average':assignment,'previous_exam_score':previous,'sleep_hours':sleep,'internet_access':internet,'extracurricular':extracurricular}])
    if run:
        score = float(np.clip(reg.predict(sample)[0],0,100))
        classifier = joblib.load(MODELS/models[selected])
        result = classifier.predict(sample)[0]
        a,b,c = st.columns(3)
        a.metric('Điểm cuối kỳ dự đoán',f'{score:.1f}/100')
        b.metric('Kết quả phân loại', 'Đạt' if result=='Pass' else 'Chưa đạt')
        c.metric('Thuật toán',selected)
        st.info('Đây là kết quả ước lượng từ dữ liệu minh hoạ, không phải kết luận chắc chắn về năng lực hay kết quả thực tế của sinh viên.')
with tab2:
    st.subheader('So sánh hiệu năng')
    cm = pd.read_csv(REPORTS/'classification_metrics.csv')
    st.dataframe(cm, use_container_width=True, hide_index=True)
    fig = px.bar(cm, x='Model', y=['Accuracy','Precision','Recall','F1'], barmode='group', title='Các chỉ số phân loại trên tập kiểm tra')
    st.plotly_chart(fig,use_container_width=True)
    rm = json.loads((REPORTS/'regression_metrics.json').read_text(encoding='utf-8'))
    x,y,z = st.columns(3)
    x.metric('MAE',rm['MAE']); y.metric('RMSE',rm['RMSE']); z.metric('R²',rm['R2'])
    st.caption('MAE/RMSE càng thấp thường càng tốt; R² càng gần 1 thường cho thấy mô hình giải thích dữ liệu tốt hơn.')
with tab3:
    st.subheader('Tổng quan dữ liệu')
    a,b,c = st.columns(3); a.metric('Số bản ghi',len(df)); b.metric('Điểm trung bình',f"{df.final_score.mean():.1f}"); c.metric('Tỷ lệ đạt',f"{(df.pass_status=='Pass').mean()*100:.1f}%")
    fig = px.histogram(df,x='final_score',nbins=20,title='Phân phối điểm cuối kỳ')
    st.plotly_chart(fig,use_container_width=True)
    fig2 = px.scatter(df,x='study_hours_per_day',y='final_score',color='pass_status',title='Giờ tự học và điểm cuối kỳ',labels={'study_hours_per_day':'Giờ tự học/ngày','final_score':'Điểm cuối kỳ'})
    st.plotly_chart(fig2,use_container_width=True)
    st.dataframe(df.head(20),use_container_width=True)
with tab4:
    st.subheader('Nhóm sinh viên bằng K-Means')
    bundle = joblib.load(MODELS/'kmeans_clusters.joblib')
    clustered = df.copy(); clustered['Cụm'] = bundle['model'].labels_.astype(str)
    fig = px.scatter(clustered,x='study_hours_per_day',y='final_score',color='Cụm',hover_data=['attendance_percent','assignment_average'],title='Các cụm theo giờ tự học và điểm cuối kỳ')
    st.plotly_chart(fig,use_container_width=True)
    st.dataframe(pd.read_csv(REPORTS/'cluster_summary.csv'),use_container_width=True)
    st.caption('K-Means là học không giám sát: cụm chỉ biểu thị nhóm có đặc điểm tương tự, không tự động có nghĩa là nhóm tốt/xấu.')
